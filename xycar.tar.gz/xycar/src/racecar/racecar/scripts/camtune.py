#!/usr/bin/env python
#123
import cam_tune

if __name__ == '__main__':
    cam_tune.main()
